goc2p
=====

Go Concurrency Programming Project.

An example project for book 'Go Programming & Concurrency in Practice' (《Go并发编程实战》).
